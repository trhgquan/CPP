//
// WATSCORE - https://codechef.com/problems/WATSCORE
// Codechef December Challenge 2019
// Code by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>

int max(int a, int b) {
	return (a > b) ? a : b;
}

int main() {
	int T, N, u, v, score;

	scanf("%d", &T);
	while (T--) {
		int a[10] = {0};
		scanf("%d", &N);

		for (int i = 1; i <= N; ++i) {
			scanf("%d%d", &u, &v);
			if (u >= 9) continue;
			else a[u] = max(a[u], v);
		}

		score = 0;
		for (int i = 1; i <= 8; ++i)
			score += a[i];
		printf("%d\n", score);
	}
	return 0;
}
