//
//  LIFELTD - https://codechef.com/problems/LIFELTD
//  Code by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>

int main() {
    char Graph[4][4];
    int T; scanf("%d", &T);
    while (T--) {
        for (int i = 0; i < 3; ++i)
            scanf("%s", Graph[i]);
        int found = 0;
        for (int i = 0; i <= 1; ++i)
            for (int j = 0; j <= 1; ++j)
                if (Graph[i][j] == 'l' &&
                    Graph[i + 1][j] == 'l' &&
                    Graph[i + 1][j + 1] == 'l') {found = 1; break;}
        if (found) printf("yes\n");
        else printf("no\n");
    }
    return 0;
}
