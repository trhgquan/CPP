/**
 * PSHOT - https://codechef.com/problems/PSHOT
 * Codechef February Cook-off 2020 - Division 2
 * Code by @trhgquan - https://github.com/trhgquan
 */

#include<iostream>
#include<string>
using namespace std;

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    // Write codes here
    int T; cin >> T;
    while (T--) {
        string goals; int N; cin >> N >> goals;
        int teamA = 0, teamB = 0, slotsA = N, slotsB = N, slots = 0;

        for (int i = 0; i < 2 * N; ++i) {
            ++slots;
            if (i % 2 == 0 && goals[i] == '1') ++teamA;
            if (i % 2 != 0 && goals[i] == '1') ++teamB;
            if (i % 2 == 0) --slotsA; else --slotsB;
            if (teamA > teamB && teamA - teamB > slotsB) break;
            if (teamA < teamB && teamB - teamA > slotsA) break;
        }

        cout << slots << endl;
    }
    return 0;
}
