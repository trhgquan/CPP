//
// ALTARAY - https://codechef.com/problems/ALTARAY
// Code by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>

int main() {
  int t; scanf("%d", &t);
  int a[100001], b[100001];

  while (t--) {
    int n; scanf("%d", &n);

    // Read input
    for (int i = 1; i <= n; ++i) {
      scanf("%d", &a[i]);
      b[i] = 1;
    }

    // Count alternative arrays
    for (int i = n - 1; i > 0; --i)
      if ((a[i] > 0 && a[i + 1] < 0) ||
          (a[i] < 0 && a[i + 1] > 0)) b[i] = b[i + 1] + 1;

    // Print result
    for (int i = 1; i < n; ++i)
      printf("%d ", b[i]);
    printf("%d\n", b[n]);
  }
  return 0;
}
