//
// PLMU - https://codechef.com/problems/PLMU
// Codechef December Challenge 2019
// Code by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>

int main() {
	int T, N, u0, u2, u; scanf("%d", &T);
	while (T--) {
		scanf("%d", &N);
		u0 = 0; u2 = 0;
		for (int i = 1; i <= N; ++i) {
			scanf("%d", &u);
			if (u == 0) ++u0;
			if (u == 2) ++u2;
		}

		u0 = u0 * (u0 - 1) / 2;
		u2 = u2 * (u2 - 1) / 2;
		printf("%d\n", u0 + u2);
	}
	return 0;
}
