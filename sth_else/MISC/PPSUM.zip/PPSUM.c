//
// PPSUM - https://codechef.com/problems/PPSUM
// Code by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>

int sum(int n) {
  int s = 0;
  for (int i = 1; i <= n; ++i) s += i;
  return s;
}
int main() {
  int T, a, b, s; scanf("%d", &T);
  while (T--) {
    scanf("%d%d", &a, &b);
    s = sum(b);
    for (int i = 1; i <= a - 1; ++i)
      s = sum(s);
    printf("%d\n", s);
  }
  return 0;
}
