/**
 * UCV2013I - https://www.spoj.com/problems/UCV2013I
 * Code by @trhgquan - https://github.com/trhgquan
 */
 
#include<stdio.h>
#include<math.h>
#define PIE 3.14159265358979323846264338327950288

int main() {
  while (1) {
    double r, N; scanf("%lf%lf", &r, &N);
    if (r == 0 && N == 0) break;
    
    double radian = PIE / (2 * N);
    printf("%.2lf\n", r / sin(radian));
  }
  return 0;
}