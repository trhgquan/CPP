//
//  BFRIEND - https://codechef.com/problems/BFRIEND
//  Codechef January Lunchtime 2020
//  C0de by @trhgquan - https://github.com/trhgquan
//

#include<climits>
#include<iostream>
using namespace std;

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    int T; cin >> T;
    while (T--) {
        long N, a, b, c; cin >> N >> a >> b >> c;
        long max = LONG_MAX;
        for (long i = 1; i <= N; ++i) {
            long F; cin >> F;
            if (abs(F - a) + abs(F - b) + c < max) max = abs(F - a) + abs(F - b) + c;
        }
        cout << max << endl;
    }
    return 0;
}
