//
// CHEALG - https://codechef.com/problems/CHEALG
// Codechef December Lunchtime 2019
// Code by @trhgquan - https://github.com/trhgquan
//

#include<iostream>
#include<string>
using namespace std;

/**
 * Count how many characters are there in a number
 */
int countChars(int n) {
    int counts = 0;
    if (n < 10) return 1;
    while (n > 0) {
        n /= 10;
        counts++;
    }
    return counts;
}

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    int T; cin >> T;

    while (T--) {
        string s; cin >> s;
        unsigned total_length = 0;
        int count = 1;

        for (unsigned i = 0; i < s.size() - 1; ++i) {
            if (s[i] == s[i + 1]) count++;
            else {
                total_length += countChars(count) + 1;
                count = 1;
            }
        }

        total_length += countChars(count) + 1;

        if (total_length < s.size()) cout << "YES" << endl;
        else cout << "NO" << endl;
    }
    return 0;
}
