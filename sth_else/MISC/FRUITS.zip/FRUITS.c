//
// FRUITS - https://codechef.com/problems/FRUITS
// Code by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>

int min(int a, int b) {
  return (a < b) ? a : b;
}

int main() {
  int t; scanf("%d", &t);
  while(t--) {
    int n, m, k; scanf("%d%d%d", &n, &m, &k);

    // max = (n + m) - min(n, m);
    // min = min(n, m);

    if (min(n, m) + k >= (n + m) - min(n, m))
      printf("0");
    else printf("%d", (n + m) - min(n, m) - (min(n, m) + k));

    printf("\n");
  }
  return 0;
}
