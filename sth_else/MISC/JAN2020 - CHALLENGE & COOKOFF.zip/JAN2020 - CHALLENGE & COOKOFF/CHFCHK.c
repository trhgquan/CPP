//
// CHFCHK - https://codechef.com/problems/CHFCHK
// Codechef January Cook-off 2020
// Code by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>

int main() {
  int T, N, m, u; scanf("%d", &T);
  while (T--) {
    scanf("%d", &N); scanf("%d", &m);
    for (int i = 2; i <= N; ++i) {
      scanf("%d", &u);
      if (u < m) m = u;
    }
    printf("%d\n", m);
  }

  return 0;
}
