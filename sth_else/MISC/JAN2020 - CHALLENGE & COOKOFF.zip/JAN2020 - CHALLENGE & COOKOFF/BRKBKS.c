//
//  BRKBKS - https://codechef.com/problems/BRKBKS
//  Codechef January Long Challenge 2020
//  Code by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>

int main() {
    short T; scanf("%hd", &T);
    while (T--) {
        short S; scanf("%hd", &S);
        short a[4]; for (short i = 1; i <= 3; ++i) scanf("%hd", &a[i]);

        if (a[1] + a[2] + a[3] <= S)
            printf("1\n");
        else if (a[1] + a[2] + a[3] > S && ((a[1] + a[2] <= S) || (a[2] + a[3]) <= S))
            printf("2\n");
        else printf("3\n");
    }
    return 0;
}
