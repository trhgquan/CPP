/**
 * UCV2013J - https://www.spoj.com/problems/UCV2013J
 * Code by @trhgquan - https://github.com/trhgquan
 */

#include<iostream>
using namespace std;

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    while (true) {
        int N; cin >> N;
        if (N == 0) break;

        int ans = 0;

        for (int i = 1; i <= N; ++i) {
            int u; cin >> u;
            if (((N % 2 == 0) && (i > N - (N / 2))) ||
                ((N % 2 != 0) && (i >= N - (N / 2))))
                ans += u;
        }

        cout << ans << endl;
    }
    return 0;
}
