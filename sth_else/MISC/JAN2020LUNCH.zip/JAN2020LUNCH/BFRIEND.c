//
//  STFOOD - https://codechef.com/problems/BFRIEND
//  Codechef January Lunchtime 2020
//  C0de by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>
#include<limits.h>

long abs(long a) {
    if (a > 0) return a;
    return -a;
}

int main() {
    int T; scanf("%d", &T);
    while(T--) {
        int N; scanf("%d", &N);
        long a, b, c; scanf("%ld%ld%ld", &a, &b, &c);
        long max = LONG_MAX;
        for (int i = 1; i <= N; ++i) {
            long F; scanf("%ld", &F);
            if (abs(F - a) + abs(F - b) + c < max) max = abs(F - a) + abs(F - b) + c;
        }
        printf("%ld\n", max);
    }
    return 0;
}
