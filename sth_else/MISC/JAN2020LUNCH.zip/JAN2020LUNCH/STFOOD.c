//
//  STFOOD - https://codechef.com/problems/STFOOD
//  Codechef January Lunchtime 2020
//  C0de by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>

int main() {
    int T; scanf("%d", &T);
    while (T--) {
        int N; scanf("%d", &N);
        int max = 0;

        for (int i = 1; i <= N; ++i) {
            int S, P, V; scanf("%d%d%d", &S, &P, &V);
            if ((P / (S + 1)) * V > max) max = (P / (S + 1)) * V;
        }

        printf("%d\n", max);
    }
    return 0;
}
