/**
 * SLAB - https://codechef.com/problems/SLAB
 * Codechef February Cook-off 2020 - Division 2
 * Code by @trhgquan - https://github.com/trhgquan
 */

#include<iostream>
#include<iomanip>
using namespace std;

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    cout << fixed << setprecision(0);
    // Write codes here
    int T; cin >> T;
    while (T--) {
        int N; cin >> N;
        if (N <= 250000) cout << N;
        else if (N > 250000 && N <= 500000)
            cout << N - (N - 250000) * 0.05;
        else if (N > 500000 && N <= 750000)
            cout << N - ((N - 500000) * 0.1 + 250000 * 0.05);
        else if (N > 750000 && N <= 1000000)
            cout << N - ((N - 750000) * 0.15 + 250000 * 0.15);
        else if (N > 1000000 && N <= 1250000)
            cout << N - ((N - 1000000) * 0.2 + 250000 * 0.3);
        else if (N > 1250000 && N <= 1500000)
            cout << N - ((N - 1250000) * 0.25 + 250000 * 0.5);
        else cout << N - ((N - 1500000) * 0.3 + 250000 * 0.75);
        cout << endl;
    }
    return 0;
}
