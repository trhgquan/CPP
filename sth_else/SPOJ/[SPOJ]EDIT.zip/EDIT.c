//
//  EDIT - https://www.spoj.com/problems/EDIT
//  Code by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>
#include<string.h>

// Check if a character is uppercase
int isUpper(char a) {
    return a >= 'A' && a <= 'Z';
}

// Check if 2 character are both upper or both lower
int isMatch(char a, char b) {
    return (isUpper(a) && isUpper(b)) || (!isUpper(a) && !isUpper(b));
}

int main() {
    char s[1001];
    while (scanf("%s", s) != EOF) {
        // First character does not need to change.
        int count_zero = 1;
        int count_one = 0;
        // Mark 1 if the character needs to be changed.
        int a[1001] = {0};

        for (unsigned i = 1; i < strlen(s); ++i) {
            // If two adjacent character is both upper or lowercase,
            // and the previous character has not been changed,
            // increase the counting.
            if ((isMatch(s[i], s[i - 1]) && a[i - 1] != 1) ||
                (!isMatch(s[i], s[i - 1]) && a[i - 1] == 1))
                ++a[i];

            if (a[i] == 1) ++count_one;
            else ++count_zero;
        }

        if (count_one < count_zero) printf("%d\n", count_one);
        else printf("%d\n", count_zero);
    }
    return 0;
}
