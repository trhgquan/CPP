//
//  STFOOD - https://codechef.com/problems/STFOOD
//  Codechef January Lunchtime 2020
//  C0de by @trhgquan - https://github.com/trhgquan
//

#include<iostream>
using namespace std;

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    int T; cin >> T;
    while (T--) {
        int N; cin >> N;
        int max = 0;

        for (int i = 1; i <= N; ++i) {
            int S, V, P; cin >> S >> P >> V;
            if ((P / (S + 1)) * V > max) max = (P / (S + 1)) * V;
        }

        cout << max << endl;
    }
    return 0;
}
