//
// RECIPE - https://codechef.com/problems/RECIPE
// Code by @trhgquan - https://github.com/trhgquan
//

#include<stdio.h>

int GCD(int a, int b) {
  if (b == 0) return a;
  return GCD(b, a % b);
}

int main() {
  int T; scanf("%d", &T);
  int a[51];
  for (int i = 1; i <= T; ++i) {
    int N; scanf("%d", &N);
    int gcd = 32767;

    for (int j = 0; j < N; ++j) scanf("%d", &a[j]);

    for (int j = 0; j < N - 1; ++j)
      if (GCD(a[j], a[j + 1]) < gcd) gcd = GCD(a[j], a[j + 1]);


    for (int j = 0; j < N - 1; ++j)
      printf("%d ", a[j] / gcd);
    printf("%d\n", a[N - 1] / gcd);
  }
  return 0;
}
