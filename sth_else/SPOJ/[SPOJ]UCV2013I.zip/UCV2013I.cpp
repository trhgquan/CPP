/**
 * UCV2013I - https://www.spoj.com/problems/UCV2013I
 * Code by @trhgquan - https://github.com/trhgquan
 */

#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;

#define PIE 3.14159265358979323846264338327950288

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
    // Two digit after "."
    cout << setprecision(2) << fixed;
    while (true) {
        double r, N; cin >> r >> N;
        if (r == 0 && N == 0) break;

        double radian = PIE / (2 * N);
        cout << r / sin(radian) << endl;
    }
    return 0;
}
