//
//  EDIT - https://www.spoj.com/problems/EDIT
//  Code by @trhgquan - https://github.com/trhgquan
//

#include<iostream>
#include<string>
using namespace std;

// Check if a character is upper
bool isUpper(char a) {
    return a >= 'A' && a <= 'Z';
}

// Check if 2 character are both upper or both lower
bool isMatch(char a, char b) {
    return (isUpper(a) && isUpper(b)) || (!isUpper(a) && !isUpper(b));
}

int main() {
    string s;
    while (cin >> s) {
        // First character does not need to change.
        int count_zero = 1;
        int count_one = 0;
        // Mark 1 if the character needs to be changed.
        int a[1001] = {0};

        for (unsigned i = 1; i < s.size(); ++i) {
            // If two adjacent character is both upper or lowercase,
            // and the previous character has not been changed,
            // increase the counting.
            if ((isMatch(s[i], s[i - 1]) && a[i - 1] != 1) ||
                (!isMatch(s[i], s[i - 1]) && a[i - 1] == 1))
                ++a[i];

            if (a[i] == 0) ++count_zero;
            else ++count_one;
        }

        // This is a trick. If number of changes is more than number of unchanged,
        // those unchanged is what needs to be changed.
        cout << ((count_one < count_zero) ? count_one : count_zero) << endl;
    }
    return 0;
}
